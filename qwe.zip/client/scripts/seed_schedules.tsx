import { db } from "../../server/db";
import { schedules } from "../../shared/schema";
import { eq, and, gte, lte } from "drizzle-orm";
import { addDays, setHours, setMinutes, format } from "date-fns";

// Configuration
const USER_ID = "ab20cde9-a834-4b49-bf93-2db071427cbc";
const START_DATE = new Date("2025-11-01");
const END_DATE = new Date("2025-11-25");

async function seed() {
  console.log("------------------------------------------------");
  console.log("Starting Schedule Seeding for User:", USER_ID);
  console.log("------------------------------------------------");

  // 1. Clean up existing schedules for this user in this range to avoid duplicates
  console.log("Cleaning old schedules...");
  
  // Note: We filter by date range to avoid deleting future real schedules if any
  const startTimestamp = START_DATE.getTime();
  const endTimestamp = END_DATE.getTime();

  await db.delete(schedules).where(
    and(
      eq(schedules.userId, USER_ID),
      gte(schedules.date, new Date(startTimestamp)),
      lte(schedules.date, new Date(endTimestamp))
    )
  );

  let currentDate = START_DATE;

  while (currentDate <= END_DATE) {
    // Skip Weekends (0 = Sunday, 6 = Saturday)
    const day = currentDate.getDay();
    if (day !== 0 && day !== 6) {
      
      const dateStr = format(currentDate, "yyyy-MM-dd");
      console.log(`Creating schedule for ${dateStr}...`);

      // Define Morning Shift: 8:00 AM to 4:00 PM (16:00)
      const shiftDate = setHours(setMinutes(currentDate, 0), 0); // Midnight
      const startTime = setMinutes(setHours(currentDate, 8), 0); // 08:00 AM
      const endTime = setMinutes(setHours(currentDate, 16), 0);  // 04:00 PM

      // Insert Schedule
      await db.insert(schedules).values({
        userId: USER_ID,
        date: shiftDate,
        startTime: startTime,
        endTime: endTime,
        type: "morning",
        title: "Morning Shift",
        description: "Regular Cashier Shift",
        location: "Main Branch",
        shiftRole: "cashier",
        isAllDay: false,
        status: "scheduled"
      });
    }

    // Move to next day
    currentDate = addDays(currentDate, 1);
  }

  console.log("------------------------------------------------");
  console.log("Seeding complete! Check Shift Management.");
  console.log("------------------------------------------------");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});