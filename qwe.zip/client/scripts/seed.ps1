# --- CONFIGURATION ---
$UserId = "ab20cde9-a834-4b49-bf93-2db071427cbc"
$BaseUrl = "http://localhost:5000/api/attendance"
$StartDay = 1
$EndDay = 25
$Year = 2025
$Month = 11

Write-Host "------------------------------------------------"
Write-Host "Seeding Attendance: 8 Hours Work / 1 Hour Break"
Write-Host "User ID: $UserId"
Write-Host "------------------------------------------------"

# Loop through the days
for ($day = $StartDay; $day -le $EndDay; $day++) {
    
    # Create Date Object
    $CurrentDate = Get-Date -Year $Year -Month $Month -Day $day
    $DateStr = $CurrentDate.ToString("yyyy-MM-dd")

    # Skip Weekends (Saturday & Sunday)
    if ($CurrentDate.DayOfWeek -eq 'Saturday' -or $CurrentDate.DayOfWeek -eq 'Sunday') {
        Write-Host "Skipping Weekend: $DateStr" -ForegroundColor DarkGray
        continue
    }

    Write-Host "Processing $DateStr..." -NoNewline

    # --- DEFINE TIMESTAMPS (ISO 8601 Format) ---
    # Note: .ToUniversalTime() ensures the format has the 'Z' at the end for API consistency
    
    # 8:00 AM - Clock In
    $TimeIn = $CurrentDate.Date.AddHours(8).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    
    # 12:00 PM - Break Start
    $BreakStart = $CurrentDate.Date.AddHours(12).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    
    # 1:00 PM - Break End (1 Hour Duration)
    $BreakEnd = $CurrentDate.Date.AddHours(13).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    
    # 5:00 PM - Clock Out (8 Hours Work total)
    $TimeOut = $CurrentDate.Date.AddHours(17).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")

    # --- EXECUTE REQUESTS ---

    try {
        # 1. Clock In
        $Body = @{ userId = $UserId; date = $TimeIn; notes = "Regular Shift" } | ConvertTo-Json
        Invoke-RestMethod -Uri "$BaseUrl/clock-in" -Method Post -Body $Body -ContentType "application/json" | Out-Null

        # 2. Start Break
        $Body = @{ userId = $UserId; date = $BreakStart; breakType = "lunch" } | ConvertTo-Json
        Invoke-RestMethod -Uri "$BaseUrl/break-start" -Method Post -Body $Body -ContentType "application/json" | Out-Null

        # 3. End Break
        $Body = @{ userId = $UserId; date = $BreakEnd } | ConvertTo-Json
        Invoke-RestMethod -Uri "$BaseUrl/break-end" -Method Post -Body $Body -ContentType "application/json" | Out-Null

        # 4. Clock Out
        $Body = @{ userId = $UserId; date = $TimeOut } | ConvertTo-Json
        Invoke-RestMethod -Uri "$BaseUrl/clock-out" -Method Post -Body $Body -ContentType "application/json" | Out-Null

        Write-Host " [OK]" -ForegroundColor Green
    }
    catch {
        Write-Host " [ERROR]" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

Write-Host "------------------------------------------------"
Write-Host "Seeding Complete!"